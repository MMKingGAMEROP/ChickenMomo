package com.example.chickenmomo;

import net.fabricmc.api.ModInitializer;
import net.minecraft.item.FoodComponent;
import net.minecraft.item.Item;
import net.minecraft.item.ItemGroup;
import net.minecraft.util.Identifier;
import net.minecraft.util.registry.Registry;

public class ChickenMomoMod implements ModInitializer {
    public static final String MODID = "chickenmomo";
    public static final Item CHICKEN_MOMO = new Item(
        new Item.Settings()
            .group(ItemGroup.FOOD)
            .maxCount(64)
            .food(new FoodComponent.Builder()
                .hunger(8)
                .saturationModifier(0.975F) // hunger*2*modifier = 8*2*0.975 = 15.6 saturation
                .alwaysEdible()
                .build())
    );

    @Override
    public void onInitialize() {
        Registry.register(Registry.ITEM, new Identifier(MODID, "chicken_momo"), CHICKEN_MOMO);
        System.out.println("[ChickenMomo] Initialized");
    }
}
